package MobileBeans;

public class Reciept extends MobileBean {

	
	
	int orderId;
	double pricewithgst;
	String purchasedate;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getPricewithgst() {
		return pricewithgst;
	}
	public void setPricewithgst(double pricewithgst) {
		this.pricewithgst = pricewithgst;
	}
	public String getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}
	public Reciept() {
		
		this.orderId = orderId;
		this.pricewithgst = pricewithgst;
		this.purchasedate = purchasedate;
	}
	
	@Override
	public String toString() {
		return 				"orderId=" + getOrderId()
		
							+ "\nCustomer Id: " + getCustId()
							+ "\nCustomer Name: " +getCustomerName()
							+ "\nAddress: " + getCustAddrs()
							+ "\nMobileNumber: " + getCustMoNo()
							+"mobileName=" + getMobileName()
							+ "\n mobileModel=" + getMobileModel()
							+ "\n mobileprice=" + getMobileprice()
							+ "\n pricewithgst=" + getPricewithgst()
							+ "\n purchasedate="+ getPurchasedate();
							
				
	}
	
	
	

}
