package com.dao;
import java.util.*;
import java.util.ArrayList.*;
import com.bean.*;
import com.service.*;
public class EmployeeDAO {
	ArrayList al;
	Employee obj;
	public EmployeeDAO(){
		al= new ArrayList();
	}
	public void storeInDAO(Employee obj) {
	
		al.add(obj);
		
		System.out.println(obj);
		
	}
	
	public Employee sendBacktoService() {
		
		obj=(Employee)al.get(0);
		return obj;
	}
	
}
