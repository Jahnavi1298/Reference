package com.ui;
import com.bean.*;
import com.dao.*;
import com.service.*;
public class Main {
public static void main(String args[]) {
	EmployeeDetailsInput inpObj= new EmployeeDetailsInput();
	
	inpObj.takeDetails();
	inpObj.displayDeatils();
}
}
