package lab1;

import java.util.Scanner;

public class Exercise2 {

        public static void fibbWithoutRec(int n)
        {
         int n1=0,n2=1,n3,i;    
         System.out.print(n1+" "+n2);//printing 0 and 1    
            
         for(i=2;i<n;++i)//loop starts from 2 because 0 and 1 are already printed    
         {    
          n3=n1+n2;    
          System.out.print(" "+n3);    
          n1=n2;    
          n2=n3;    
         }    
        }
        
        public static void fibbWithRec(int n)
        {
            int n1=0,n2=1,n3=0;    
            if(n>0){    
                 n3 = n1 + n2;    
                 n1 = n2;    
                 n2 = n3;    
                 System.out.print(" "+n3);   
                 fibbWithRec(n-1);    
             }    
         }
        
        public static void main(String[] args) {
            
            int limit,choice;
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter limit of fibboncai series");
            limit = sc.nextInt();
            
            System.out.println("Enter 1 to print fibbonaci using Recursion\nEnter 2 to print fibbonaci without Recursion");
            choice = sc.nextInt();
            
            if(choice==1)
            fibbWithRec(limit);
            else if(choice==2)
                fibbWithoutRec(limit);
            else
                System.out.println("INVALID CHOICE");
            
        }
        
}