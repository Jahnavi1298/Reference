package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;;
public class CustomerDetails 
{
	EmployeeService es = new EmployeeService();
	public void Add()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the employee records:");
		System.out.println("Employee Id:");
		int id = s.nextInt();
		System.out.println("Employee name:");
		String name = s.next();

		System.out.println("Employee designation:");
		String designation = s.next();
		
		//System.out.println("employee InsuranceScheme:");
		//String insuranceScheme = s.next();
		System.out.println("Employee Salary:");
		float salary = s.nextFloat();
		Employee emp = new Employee( id,  name, designation, salary);
		es.addService(emp);
		
	}
	
	public void Retrieve()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter salary:");
		float sal = sc.nextFloat();
		//System.out.println("enter designation:");
		//String designation = sc.next();
		Employee emp = new Employee(sal);
		es.RetrieveService(emp);
	}
}
