package demo;

import java.util.TreeSet;

public class BackedCollection {
	public static void main(String args[]) {
		TreeSet<Integer> ts=new TreeSet<Integer>();
		ts.add(8);
		ts.add(3);
		ts.add(4);
		ts.add(23);
		ts.add(53);
		ts.add(-9);
		ts.add(35);
		ts.add(12);
		System.out.println(ts);
		TreeSet<Integer> tsSubset=new TreeSet<Integer>();
		tsSubset=(TreeSet<Integer>)ts.subSet(4, true, 53, true);
		ts.add(45);
		System.out.println(ts);
		System.out.println(tsSubset);
	}

}
