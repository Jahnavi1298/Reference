package demo;
import java.util.*;
class Person implements Comparable<Person>
{
	private String name;
	private int age;
	public Person(String name,int age) {
		this.name=name;
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	@Override
	public String toString() {
		return name+" "+age;
	}
	public int compareTo(Person per) {
		if(this.age==per.age)
			return 0;
		else
			return this.age>per.age?1:-1;
	}
}
	class PersonComparatorByName implements Comparator<Person>
	{
		@Override
		public int compare(Person o1,Person o2) {
			int flag;
			flag=o1.getName().compareTo(o2.getName());
			return flag;
		}
	}
	

public class ComparatorDemo {
public static void main(String[] args) {
	Person e1=new Person("rosh",20);
	Person e2=new Person("varsh",18);
	Person e3=new Person("balaji",50);
	Person e4=new Person("rahul",10);
	Person e5=new Person("kavitha",40);
	LinkedList<Person> l1=new LinkedList<Person>();
	l1.add(e1);
	l1.add(e2          
	l1.add(e3);
	l1.add(e4);
	l1.add(e5);
	System.out.println(l1);
	Collections.sort(l1);
	System.out.println(l1);
	Collections.sort(l1,new PersonComparatorByName());
	System.out.println(l1);
	
	
}
}
