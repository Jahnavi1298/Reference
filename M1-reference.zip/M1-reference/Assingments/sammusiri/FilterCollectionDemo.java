package demo;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilterCollectionDemo {
	public static void mian(String args[]) {
		List<Integer> numberList=new ArrayList<Integer>();
		numberList.add(12);
		numberList.add(34);
		numberList.add(89);
		numberList.add(67);
		numberList.add(36);
		numberList.add(24);
		numberList.add(45);
		System.out.println(numberList);

		//more num of lines
		
		Predicate<Integer> p=new Predicate<Integer>() {
			public boolean test(Integer i) {
				boolean val=false;
				if(i%2==0)
					val=true;
				return val;
			}
			
		};
		Stream<Integer> numberStream=numberList.stream();
		Stream<Integer> filterStream=numberStream.filter(p);
		
		filterStream.forEach(System.out::println);
		System.out.println();
		
		//singleline
		
		List<Integer> evenList=numberList.stream().filter(i->1%2==0).collect(Collectors.toList());
		System.out.println(evenList);
		
		//splitup
		Stream<Integer> s=numberList.stream();
		Stream<Integer> s1=s.filter(i->i%2==0);
		List<Integer> l1=s1.collect(Collectors.toList());
		//System.out.println(l1);
		
	}

}
