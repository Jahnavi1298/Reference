package demo;
import java.util.function.*;
public class IntSupplierDemo {
	public static void main(String args[]) {
		IntSupplier supplier1=()->Integer.MAX_VALUE;
		System.out.println("max:"+supplier1.getAsInt());
		IntSupplier supplier2=()->Integer.MIN_VALUE;
		System.out.println("min:"+supplier2.getAsInt());
		int a=6;
		int b=9;
		IntSupplier supplier3=()->a*b;
		System.out.println("product:"+supplier3.getAsInt());
		IntSupplier supplier4=()->Integer.compare(a,b);
		System.out.println("Compare:"+supplier4.getAsInt());
	}

}
