package demo;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class MapCollectionDemo {
public static void main(String args[]) {
	List<Integer> numberList=Arrays.asList(3,4,5,7,6);
	Function<Integer,Integer> f=new Function<Integer,Integer>(){
		public Integer apply(Integer i) {
			return i*2;
		}
	};
	Stream<Integer>numberStream=numberList.stream();
	Stream<Integer>mapStream=numberStream.map(f);
	mapStream.forEach(System.out::println);
	
	List<Integer> MarkList=new ArrayList<Integer>();
	MarkList.add(12);
	MarkList.add(1);
	MarkList.add(19);
	MarkList.add(95);
	MarkList.add(55);
	System.out.println(MarkList);
	//single line
	List updatedMarkList=MarkList.stream().map(i->i+5).collect(Collectors.toList());
	System.out.println(updatedMarkList);
	//multiplelines
	Stream<Integer> s=MarkList.stream();
	Stream<Integer> s1=s.map(i->i*2);
	List fe=s1.collect(Collectors.toList());
	System.out.println(fe);
	
	
	
}

}
