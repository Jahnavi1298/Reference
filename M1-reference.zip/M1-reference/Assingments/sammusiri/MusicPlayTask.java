package demo;

public class MusicPlayTask implements Runnable{
	public void run() {
		System.out.println(" music is executing");
		try {
			Thread.sleep(6000);
		}catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("music"+"is resumed");
	}

}
