package demo;

public class ThreadClassDemo extends Thread{
	public void run() {
		for(int i=0;i<5;i++)
		{
			System.out.println(getName()+":"+i);
		}
	}
public static void main(String args[]) {
	ThreadClassDemo tcd=new ThreadClassDemo();
	ThreadClassDemo tcd1=new ThreadClassDemo();
	tcd.setName("hello");
	tcd.start();
	tcd1.setName("hey");
	tcd1.start();
	
}



}

