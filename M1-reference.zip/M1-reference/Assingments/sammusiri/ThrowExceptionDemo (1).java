package demo;

import java.util.Scanner;

class NegativeAgeException extends RuntimeException{
	//NegativeAgeException(String a){
		//System.out.println("negative age");
	//}
}
public class ThrowExceptionDemo {
	void display()throws Exception{
		
	}
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	NegativeAgeException ae=new NegativeAgeException();
	System.out.println("enter age");
	int age=sc.nextInt();
	try {
		if(age<0)
			//throw new NegativeAgeException("age neg");
		throw ae;
		else
			System.out.println("age"+age);
		
	}catch(Exception e) {
		System.out.println();
		//System.out.println(e);
	}
}
}
