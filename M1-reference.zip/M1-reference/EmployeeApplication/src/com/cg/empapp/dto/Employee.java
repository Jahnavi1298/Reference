package com.cg.empapp.dto;

public class Employee {

	private int empId;
	private String empName;
	private int empSal;
	
	
}
