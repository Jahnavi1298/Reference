package com.cg.mm.main;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.mm.dto.Product;
import com.cg.mm.exception.PMSException;
import com.cg.mm.service.IProductService;
import com.cg.mm.service.ProductServiceImp;

public class Main {
	
	
	public static void main(String[] arg) {
		
		
		Scanner scanner=null;
		
		String continueChoice="";
		
		IProductService service=new ProductServiceImp();
		
		do {
			
			System.out.println("******************Product Management System*******************");
			System.out.println("1. Add Product");
			System.out.println("2  Search Product by Id");
			System.out.println("3  Display All Product ");
			System.out.println("4. Delete Product");
			System.out.println("5 Exit");
			
			int choice=0;
			boolean choiceFlag=false;
			do
			{
				
				scanner=new Scanner(System.in);
				System.out.println("Enter your Choice: ");
				
				try {
					
					choice=scanner.nextInt();
					choiceFlag=true;
					switch(choice) {
					
					    case 1:
					    	
					    		String productName="";
					    		boolean productNameFlag=false;
					    		
					    		do {
					    				scanner=new Scanner(System.in);
					    				System.out.println("Enter Product Name: ");
					    				productName=scanner.nextLine();
					    				
					    				try {
					    					service.validateName(productName);
					    					productNameFlag=true;
					    					
					    				}catch(PMSException e) {
					    				
					    					System.err.println(e.getMessage());
					    				}
					    			   			
					 	
					    		}while(!productNameFlag);
					    		
					    		
					    		int cost=0;
					    		boolean costFlag=false;
					    		
					    		do {
					    			scanner=new Scanner(System.in);
					    			System.out.println("Enter Product Cost");
					    			try {
					    				 cost=scanner.nextInt();
					    				 service.validateCost(cost);
					    				 costFlag=true;
					    				
					    			}catch(InputMismatchException e) {
					    				costFlag=false;
					    				System.err.println("Enter digits only");
					    				
					    			}catch(PMSException e1) {
					    				costFlag=false;
					    				System.err.println(e1.getMessage());
					    			}
					    			
					    		}while(!costFlag);
					    		
					    		String group="";
					    		boolean groupFlag=false;
					    		
					    		do {
					    			scanner=new Scanner(System.in);
					    			System.out.println("Enter group of product");
					    			group=scanner.nextLine();
					    			try {
					    				service.validateGroup(group);
					    				groupFlag=true;
					    				
					    				
					    			}catch(PMSException e) {
					    				System.err.println(e.getMessage());
					    				
					    			}
					    			
					    			
					    		}while(!groupFlag);
					    		
					    		Product product=new Product(productName,cost,group);
					    		
					    		try {
					    			
					    			int generateId=service.addProduct(product);
					    			Date date=new Date();
					    			
					    			System.out.println("Your product is successfully added with id= "+generateId+" at "+date);
					    			
					    			
					    		}catch(PMSException e) {
					    			e.getStackTrace();
					    		}
					    		break;
					    case 2:
					    	
					    		int productId=0;
					    		boolean productIdFlag=false;
					    		
					    		do {
					    			scanner=new Scanner(System.in);
					    			System.out.println("Enter Product Id for search");
					    			Product productData=null;
					    			try {
					    				productId=scanner.nextInt();
					    				productData=service.validateId(productId);
					    				
					    				System.out.println(productData);
					    				productIdFlag=true;
					    			
					    			}catch(InputMismatchException e) {
					    				productIdFlag=false;
					    				System.err.println("product id should be digits");
					    			}catch(PMSException e1) {
					    				productIdFlag=false;
					    				System.out.println(e1.getMessage());
					    			}
					    				
					    			
					    		}while(!productIdFlag);
					    		
					    		break;
					    case 3:
					    	
					    	Map<Integer,Product> map=service.getAllProduct();
					    	
					    	System.out.println(map);
					    	
							break;
							
							
					    case 4:
							
							int productDeleteId = 0;
							boolean productDeleteIdFalg = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter Product Id to delete:");
								try {
									productDeleteId = scanner.nextInt();
									productDeleteIdFalg= false;
									Product productdel;
									try {
										productdel = service.deleteProduct(productDeleteId);
										System.out.println("product deleted: "+productdel);
										productDeleteIdFalg= true;
										
									} catch (PMSException e1) {
										productDeleteIdFalg = false;
										System.err.println(e1.getMessage());
									}

								} catch (InputMismatchException e) {
									productDeleteIdFalg = false;
									System.err.println("Id should be digits");
								}
							} while (!productDeleteIdFalg);

							break;		
					    case 5:
					    	System.out.println("*** Thank you *** ");
							System.exit(0);
							break;
							
						default:
							choiceFlag = false;
							System.out.println("input should be 1 2 3 4 5");
							break;					
					}
										
				}catch(InputMismatchException e) {
					
					
					choiceFlag=false;
					System.err.println("Please enter digits only");
					
				}
				
			}while(!choiceFlag);
			
			
		
			
			
			scanner=new Scanner(System.in);
			System.out.println("do you want to continue again\n");
			continueChoice=scanner.nextLine();
			
			
			
		}while(continueChoice.equalsIgnoreCase("yes"));
		
		scanner.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	

}
